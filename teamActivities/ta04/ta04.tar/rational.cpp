/***************************************************************
 * File: rational.cpp
 * Author: (your name here)
 * Purpose: Contains the method implementations for the Rational class.
 ***************************************************************/

#include "rational.h"
#include <iostream>
// put your method bodies here
void rational::prompt()
{
  std::cout << "Top: ";
  std::cin >> top;
  std::cout << "Bottom: ";
  std::cin >> bottom;
}
void rational::display()
{
   std::cout << top << "/" << bottom << "\n";
}
void rational::displayDecimal()
{
  std::cout << ((1.0)*top) / bottom << "\n";
}
