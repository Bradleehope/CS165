
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

void questions()
{
   char book[100];
   cout << "Favorite Book? :";
   cin.getline (book, 100);
   
   switch(book[100]
      case 'h'
         
   cout << endl << book;
}

/**********************************************************************

 ***********************************************************************/
int main()
{
   cout.setf(ios::fixed);
   cout.setf(ios::showpoint);
   cout.precision(2);

   questions();

   return 0;
}
