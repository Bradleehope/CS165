#include <iostream>
using namespace std;

int main ()
{
   cout << "hi mom";
   return 0;
}
