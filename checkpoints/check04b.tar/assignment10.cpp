
/***********************************************************************
* Program:
*    Assignment 10, Hello World
*    Brother Cook, CS124
* Author:
*    Bradlee Rothwell
* Summary: 
*    
*
*    Estimated:  0.0 hrs   
*    Actual:     0.0 hrs
*      Please describe briefly what was the most difficult part.
************************************************************************/

#include <iostream>
using namespace std;

/**********************************************************************
 * Add text here to describe what the function "main" does. Also don't forget
 * to fill this out with meaningful text or YOU WILL LOSE POINTS.
 ***********************************************************************/
int main()
{
   cout << "Hello World\n";
   return 0;
}


