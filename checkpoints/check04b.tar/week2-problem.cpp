/***********************************************************************
* Program:
*    Checkpoint 00, Week 2 problem          
*    Brother Cook, CS165
* Author:
*   Bradlee Rothwell 
* Problem Statement: 
*  Ask for a user for number of friends. Then create a struct containing a ice cream
*  flavor, number of toppings, and color of sprinkles. Ask for each person's combination and put
*  that into a struct and then ask for the users favorite flavor
*  toppings, and color. Print out all combinations 
*
*    Estimated:  0.0 hrs   
*    Actual:     0.0 hrs
*      Please describe briefly what was the most difficult part.
************************************************************************/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;

struct icecream
{
   string flavor;
   int toppings;
   string color;
};

int getFriends()
{
   int friends;
   cout << "How many friends are coming for ice cream?";
   cin >> friends;
   cout << endl;
   return friends;
}

void askQuestions(int friends, icecream & a)
{
   for(int x = 1; x <= friends; x++)
   {
     cout << "Friend #" << x << " favorite flavor? ";
     getline(cin, a.flavor);
     cout << endl;
     cout << "Friend #" << x << " wants how many toppings? ";
     cin >> a.toppings;
     cout << endl;
     cout << "Friend #" << x << " wants what color of sprinkles? ";
     getline(cin, a.color);
     cout << endl; 
   }
}


/**********************************************************************
 * Add text here to describe what the function "main" does. Also don't forget
 * to fill this out with meaningful text or YOU WILL LOSE POINTS.
 ***********************************************************************/
int main()
{
   icecream;
   askQuestions(getFriends());
   
   return 0;
}
